************************
* Analyse: Labour market competition
*************************

 replace weight=dweight

*** TABLE 1 ***
	eststo clear
	
	global controls "age i.female married lrscale i.nation" // controls
	
	qui: eststo: oprobit proimig c.skill i.hskframe income $controls [pweight=weight] if active==1
	qui: eststo: oprobit proimig c.skill##i.hskframe c.income $controls [pweight=weight] if active==1
	qui: eststo: oprobit proimig c.skill##i.hskframe c.income $controls [pweight=weight] if active==1 & lmc1>0
	qui: eststo: oprobit proimig c.skill##i.hskframe c.income $controls [pweight=weight] if active==1 & lmc1>0.25
	qui: eststo: oprobit proimig c.skill##i.hskframe c.income $controls  [pweight=weight] if active==1 & lmc2<5	
	qui: eststo: oprobit proimig c.skill##i.hskframe c.income $controls  [pweight=weight] if active==1 & lmc3>3.5
	qui: eststo: oprobit proimig c.skill##i.hskframe c.income $controls  [pweight=weight] if active==1 & lmc4==1
	
set more off

esttab using "out/tables/Table1.rtf",replace se onecell nogap compress b(3) ///
	keep(1.hskframe 1.hskframe#c.skill skill ) ///
	star (* 0.05 ** 0.01) varwidth(12) modelwidth(8) 	///
	varlabels(1.hskframe "HS-Frame" 1.hskframe#c.skill "HS-Frame X Skill-Level" skill "Skill-Level") ///
	order(skill 1.hskframe 1.hskframe#c.skill) ///
	mtitles( "Full sample (active)" "Full sample (active)" "LMC1: high" "LMC1: very high" "LMC2: high" "LMC3: high" "LMC4") ///
	indicate("Controls=1.female*" "Country FE= 1.nation") ///
	title({\b Table 1} {\i Support for highly-skilled and low-skilled immigration - test of the labor market competition model in high risk segments of the labor market}) ///
	addnotes("Ordered Probit Coefficients shown with standard errors in parentheses. All models include a set of covariates (age, gender, marital status, political ideology and income) and country dummies.")


*** Figure 2 ***
	capture tab proimig,gen(proimig)
	
	graph dot proimig4 [pweight=weight], ///
			over(skill) over(hskframe) ///
			marker(1, msymbol(O) mlwidth(thick)) ///
			  ylabel(,nogrid) ytitle(Percentage: Allow Many) xsize(8)
			  
	graph export "out/figures/Figure2.pdf", as(pdf) replace


** Figure 3: Pred Probabilities
	qui: oprobit proimig ib(3).skill##i.hskframe c.income $controls  [pweight=weight] if active==1
	margins ib(3).skill, predict(outcome(4))  over(hskframe) post
	marginsplot, level(95)  ytitle("Predicted Probability: Allow Many") ///
		 legend(position(3) cols(1)) title("") xtitle("") xsize(8)
		
	graph export "out/figures/Figure3.pdf", as(pdf) replace
	
** Figure 4: Differences in Treatment Effects
** Set Controls
	global controls "age i.female married lrscale c.income"

	capture gen diff_s4s1 = .
	capture gen se_1 = .
	capture gen nation_num1 = . 
	capture gen est_low1 = .
	capture gen est_high1 = .

capture ssc install lincomest
** Estimation Lists
	levelsof nation, local(level) 

	local estimates_list
	foreach g of local level {
		qui oprobit proimig i.skill##i.hskframe $controls [pweight=weight] if nation == `g'
		qui margins ib(3).skill, over(hskframe) predict(outcome(4)) post
		estimates store mar1_`g'
		local estimates_list `estimates_list' e1_`g'
		qui lincomest  ((_b[1.hskframe#4.skill] -  _b[0bn.hskframe#4.skill]) - (_b[1.hskframe#1bn.skill] -  _b[0bn.hskframe#1bn.skill]))
		replace nation_num1 = `g' if nation == `g'
		matrix b1`g'=e(b)
		replace diff_s4s1 = b1`g'[1,1] if nation == `g'
		matrix V1`g' = e(V)
		replace se_1 = sqrt(V1`g'[1,1])
		replace est_low1 =   b1`g'[1,1] - 1.67*sqrt(V1`g'[1,1])  if nation == `g'
		replace est_high1 =  b1`g'[1,1] + 1.67*sqrt(V1`g'[1,1])  if nation == `g'
		}
		

	sort diff_s4s1
	capture egen tag=tag(cntry)
	capture	egen rank1 = rank(diff_s4s1) if tag
	
	labmask rank1, value(cntry)
	
	graph twoway (scatter rank1 diff_s4s1, legend(off) msymbol(O) xline(0 ///
		,lcolor(red)) yaxis(1) ///
		ylabel( 1/15,valuelabel angle(0))) ///
		(rspike est_high1 est_low1 rank1, ///
		hor ytitle("") xtitle("")) 
		
		graph export "out/figures/Figure4.pdf", as(pdf) replace
		
*** TABLE B1

	eststo clear
	
	global controls "age i.female married lrscale i.nation" // controls
	
	qui: eststo: oprobit proimig c.education##i.hskframe income $controls [pweight=weight]
	qui: eststo: oprobit proimig ib(3).education##i.hskframe income $controls [pweight=weight]
	qui: eststo: oprobit proimig c.education##i.hskframe income $controls [pweight=weight] if active == 1
	qui: eststo: oprobit proimig c.education##i.hskframe income $controls [pweight=weight] if active == 0
	
esttab using "out/tables/TableB1.rtf",replace se onecell nogap compress b(3) ///
	keep(education 1.hskframe 1.hskframe#c.education 1.education 2.education 4.education 1.education#1.hskframe 2.education#1.hskframe 4.education#1.hskframe) ///
	star (* 0.05 ** 0.01) varwidth(12) modelwidth(8) 	///
	varlabels(education "Education" 1.hskframe "HS-Frame" 1.hskframe#c.education "HS-Frame X Education" 1.education "< lower secondary" 2.education "Lower Secondary" 3.education "Upper secondary & Vocational" 4.education "Tertiary" 1.education#1.hskframe "HS-Frame X < lower secondary" 2.education#1.hskframe "HS-Frame X secondary" 3.education#1.hskframe "HS-Frame X upper secondary & vocational" 4.education#1.hskframe "HS-Frame X tertiary") ///
	order(education 1.hskframe 1.hskframe#c.education 1.education 1.education#1.hskframe 2.education 2.education#1.hskframe 3.education 3.education#1.hskframe 4.education 4.education#1.hskframe) ///
	mtitles("In Favor of High Skilled Migration" "In Favor of Low Skilled Migration" "In Favor Migration" "In Favor Migration" "In Favor Migration" "labor force: in" "labor force: out") ///
	indicate("Controls=1.female*" "Country FE=1.nation") ///
	title({\b Table B1} {\i Support for highly Skilled and Low-Skilled Immigration - Test of the Labor Market Competition Model}) ///
	addnotes("Ordered Probit Coefficients shown with standard errors in parentheses. All models include a set of covariates (age, gender, marital status, political ideology and income) and country dummies. The reference catgeory for the education dummies is 'upper secondary or vocational education'")	
		
** FIGURE B1		
	global controls "age i.female married lrscale c.income"

	capture gen est_1 = .
	capture gen se_1 = .
	capture gen nation_num1 = . 
	capture gen est_low1 = .
	capture gen est_high1 = .

	** Estimation Lists
	levelsof nation, local(level) 

	local estimates_list
	foreach g of local level {
		qui oprobit proimig i.skill##i.hskframe $controls [pweight=weight] if nation == `g'
		qui margins ib(3).skill, over(hskframe) predict(outcome(4)) post
		estimates store mar1_`g'
		local estimates_list `estimates_list' e1_`g'
		qui lincomest  _b[1.hskframe#1bn.skill] -  _b[0bn.hskframe#1bn.skill]
		replace nation_num1 = `g' if nation == `g'
		matrix b1`g'=e(b)
		replace est_1 = b1`g'[1,1] if nation == `g'
		matrix V1`g' = e(V)
		replace se_1 = sqrt(V1`g'[1,1])
		replace est_low1 =   b1`g'[1,1] - 1.67*sqrt(V1`g'[1,1])  if nation == `g'
		replace est_high1 =  b1`g'[1,1] + 1.67*sqrt(V1`g'[1,1])  if nation == `g'
		}
		
		
	capture gen est_2 = .
	capture gen se_2 = .
	capture gen nation_num2 = . 
	capture gen est_low2 = .
	capture gen est_high2 = .

	** Estimation Lists
	levelsof nation, local(level) 

	local estimates_list
	foreach g of local level {
		qui oprobit proimig i.skill##i.hskframe $controls [pweight=weight] if nation == `g'
		qui margins ib(3).skill, over(hskframe) predict(outcome(4)) post
		estimates store mar2_`g'
		local estimates_list `estimates_list' e2_`g'
		qui lincomest  _b[1.hskframe#4.skill] -  _b[0bn.hskframe#4.skill]
		replace nation_num2 = `g' if nation == `g'
		matrix b2`g'=e(b)
		replace est_2 = b2`g'[1,1] if nation == `g'
		matrix V2`g' = e(V)
		replace se_2 = sqrt(V2`g'[1,1])
		replace est_low2 =   b2`g'[1,1] - 1.67*sqrt(V2`g'[1,1])  if nation == `g'
		replace est_high2 =  b2`g'[1,1] + 1.67*sqrt(V2`g'[1,1])  if nation == `g'
		}
	
	capture gen diff_est1 = .
	replace diff_est1 = est_2 - est_1
	
	*sort est_2
	sort diff_est1
	capture egen tag=tag(cntry)
	capture	egen rank1 = rank(diff_est1) if tag
	capture gen y2 = rank1 - 0.35
	
	labmask rank1, value(cntry)
	
	graph twoway (scatter rank1 est_2, legend(off) msymbol(O) xline(0 ///
		,lcolor(red)) yaxis(1) ///
		ylabel( 1/15,valuelabel angle(0))) ///
		(rspike est_high2 est_low2 rank1, ///
		hor ytitle("") xtitle("XXX")) 		///
		|| (scatter y2 est_1, legend(off) msymbol(Oh) xline(0 ///
		,lcolor(red)) yaxis(1) ///
		ylabel( 1/15,valuelabel angle(0))) ///
		(rspike est_high1 est_low1 y2, ///
		hor ytitle("") xtitle("Treatment Effects for High and Low-Skilled Respondents")) 
		
		graph export "out/figures/FigureB1.pdf", as(pdf) replace

** TABLE B2
	eststo clear
	global controls "age i.female married lrscale i.nation" // controls
	
	capture gen lmc1_high = (lmc1>0)
	capture gen lmc1_very_high = (lmc1>0.25)
	capture gen lmc2_high = (lmc2<5)
	capture gen lmc3_high = (lmc3>3.5)


	qui: eststo: oprobit proimig c.skill##i.hskframe c.income $controls  [pweight=weight] if active==1
	qui: eststo: oprobit proimig c.skill##i.hskframe##i.lmc1_high c.income $controls  [pweight=weight] if active==1 
	qui: eststo: oprobit proimig c.skill##i.hskframe##i.lmc1_very_high c.income $controls  [pweight=weight] if active==1
	qui: eststo: oprobit proimig c.skill##i.hskframe##i.lmc2_high c.income $controls  [pweight=weight] if active==1	
	qui: eststo: oprobit proimig c.skill##i.hskframe##i.lmc3_high c.income $controls  [pweight=weight] if active==1 
	qui: eststo: oprobit proimig c.skill##i.hskframe##i.lmc4 c.income $controls  [pweight=weight] if active==1 


	
esttab using "out/tables/TableB2.rtf",replace se onecell nogap compress b(3) ///
	keep(1.hskframe 1.hskframe#c.skill 1.hskframe#1.lmc1_high 1.hskframe#1.lmc1_very_high 1.hskframe#1.lmc2_high 1.hskframe#1.lmc3_high 1.hskframe#1.lmc4 ///
		1.hskframe#1.lmc1_high#c.skill 1.hskframe#1.lmc1_very_high#c.skill 1.hskframe#1.lmc2_high#c.skill 1.hskframe#1.lmc3_high#c.skill 1.hskframe#1.lmc4#c.skill ///
		1.lmc1_high#c.skill 1.lmc1_very_high#c.skill 1.lmc2_high#c.skill 1.lmc3_high#c.skill 1.lmc4#c.skill ///
		skill 1.lmc1_high 1.lmc1_very_high 1.lmc2_high 1.lmc3_high 1.lmc4) ///
	star (* 0.05 ** 0.01) varwidth(12) modelwidth(8) 	///
	varlabels(1.hskframe "HS-Frame" 1.hskframe#c.skill "HS-Frame X Skill-Level" 1.hskframe#1.lmc1_high "HS-Frame X LMC1 high" 1.lmc1_high#c.skill "LCM1 high X Skill-Level" 1.hskframe#1.lmc1_high#c.skill "HS-Frame X LMC1 high X Skill-Level" ///
		1.hskframe#1.lmc1_very_high "HS-Frame X LMC1 very high" 1.lmc1_very_high#c.skill "LMC1 very high X Skill-Level" 1.hskframe#1.lmc1_very_high#c.skill "HS-Frame X LMC1 very high X Skill-Level" ///
		1.hskframe#1.lmc2_high "HS-Frame X LMC2 high" 1.lmc2_high#c.skill "LMC2 high X Skill-Level" 1.hskframe#1.lmc2_high#c.skill "HS-Frame X LMC2 high" ///
		1.hskframe#1.lmc3_high "HS-Frame X LMC3 high" 1.lmc3_high#c.skill "LMC3 high X Skill-Level" 1.hskframe#1.lmc3_high#c.skill "HS-Frame X LMC3 high X Skill-Level" ///
		1.hskframe#1.lmc4 "HS-Frame X LMC4" 1.lmc4#c.skill "LCM4 X Skill-Level" 1.hskframe#1.lmc4#c.skill "HS-Frame X LMC4 X Skill-Level" ///
		skill "Skill-Level" 1.lmc1_high "LMC1 high" 1.lmc1_very_high "LMC1 very high" 1.lmc2_high "LMC2 high" 1.lmc3_high "LMC3 high" 1.lmc4 "LMC4") ///
	order(1.hskframe 1.hskframe#c.skill 1.hskframe#1.lmc1_high 1.lmc1_high#c.skill 1.hskframe#1.lmc1_high#c.skill ///
		1.hskframe#1.lmc1_very_high 1.lmc1_very_high#c.skill 1.hskframe#1.lmc1_very_high#c.skill ///
		1.hskframe#1.lmc2_high 1.lmc2_high#c.skill 1.hskframe#1.lmc2_high#c.skill ///
		1.hskframe#1.lmc3_high 1.lmc3_high#c.skill  1.hskframe#1.lmc3_high#c.skill ///
		1.hskframe#1.lmc4 1.lmc4#c.skill  1.hskframe#1.lmc4#c.skill ///
		skill 1.lmc1_high 1.lmc1_very_high 1.lmc2_high 1.lmc3_high 1.lmc4) ///
	mtitles("Full sample (active)" "LMC1: high" "LMC1: very high" "LMC2: high" "LMC3: high" "LMC4") ///
	indicate("Controls=1.female*" "Country FE= 1.nation") ///
	title({\b Table B2} {\i Support for highly Skilled and Low-Skilled Immigration - Test of the Labor Market Competition Model}) ///
	addnotes("Ordered Probit Coefficients shown with standard errors in parentheses. All models include a set of covariates (age, gender, marital status, political ideology and income) and country dummies.")




	
	
