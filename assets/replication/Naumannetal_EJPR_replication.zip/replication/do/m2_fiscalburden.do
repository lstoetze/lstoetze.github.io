************************
* Analyse: Fiscal Burden
*************************

	use "in/ESS/ESS_cleaned_merged.dta", clear
	replace weight=dweight

** Table 2
	eststo clear
	global controls "age i.female married c.education lrscale i.nation"

	qui: eststo: oprobit proimig c.income##i.hskframe $controls  [pweight=weight]
	qui: eststo: oprobit proimig c.income##i.hskframe $controls  [pweight=weight] if fe2==1
	qui: eststo: oprobit proimig c.income##i.hskframe $controls  [pweight=weight] if fe2==0
	qui: eststo: oprobit proimig i.hskframe##ib(3).income $controls  [pweight=weight]
	qui: eststo: oprobit proimig i.hskframe##ib(3).income $controls  [pweight=weight] if fe2==1
	qui: eststo: oprobit proimig i.hskframe##ib(3).income $controls  [pweight=weight] if fe2==0

esttab using "out/tables/Table2.rtf",replace se onecell nogap compress b(3) ///
	keep(1.hskframe income 1.hskframe#c.income 1.income 2.income 4.income 5.income 1.hskframe#1.income 1.hskframe#2.income 1.hskframe#4.income 1.hskframe#5.income) ///
	star (* 0.05 ** 0.01) varwidth(12) modelwidth(8) 		///
	varlabels(1.hskframe "HS-Frame" 1.income "Q1" 2.income "Q2" 4.income "Q4" 5.income "Q5" 1.hskframe#1.income "HS-Frame X Q1" 1.hskframe#2.income "HS-Frame X Q2" 1.hskframe#4.income "HS-Frame X Q4" 1.hskframe#5.income "HS-Frame X Q5") ///
	order(1.hskframe income 1.hskframe#c.income 1.income 1.hskframe#1.income 2.income 1.hskframe#2.income 4.income 1.hskframe#4.income 5.income 1.hskframe#5.income) ///
	mtitles("Both" "Fiscal Exposure: High" "Fiscal Exposure: Low" "Both" "Fiscal Exposure: High" "Fiscal Exposure: Low") ///
	indicate("Controls=1.female*" "Country FE= 1.nation") ///
	title({\b Table 2} {\i Support for highly Skilled and Low-Skilled Immigration - test of the Fiscal Burden Model}) ///
	addnotes("Ordered Probit Coefficients shown with standard errors in parentheses. All models include a set of covariates (age, gender, marital status, political ideology and education) and country dummies. The reference catgeory for the income dummies is 'Q3'")

** Table 3
	eststo clear
	qui: eststo: oprobit proimig i.hskframe##c.income $controls  [pweight=weight] if fe2==1
	qui: eststo: oprobit proimig i.hskframe##c.income $controls  [pweight=weight] if fe2==0
	qui: eststo: oprobit proimig i.hskframe##c.income $controls  [pweight=weight] if fe4==1
	qui: eststo: oprobit proimig i.hskframe##c.income $controls  [pweight=weight] if fe4==0
	qui: eststo: oprobit proimig i.hskframe##c.income $controls  [pweight=weight] if fe6==1
	qui: eststo: oprobit proimig i.hskframe##c.income $controls  [pweight=weight] if fe6==0

esttab using "out/tables/Table3.rtf",replace se onecell nogap compress b(3) ///
	keep(1.hskframe 1.hskframe#c.income income) ///
	star (* 0.05 ** 0.01) varwidth(12) modelwidth(8) 	///
	varlabels(1.hskframe "HS-Frame" 1.hskframe#c.income "HS-Frame X Income" income "Income") ///
	order(1.hskframe income 1.hskframe#c.income) ///
	mtitles("FE1: High" "FE1: Low" "FE2: High" "FE2: Low" "FE3: High" "FE3: Low") ///
	indicate("Controls=1.female*" "Country FE= 1.nation") ///
	title({\b Table 1} {\i Support for highly-skilled and low-skilled immigration - test of the fiscal burden model}) ///
	addnotes("Ordered Probit Coefficients shown with standard errors in parentheses. All models include a set of covariates (age, gender, marital status, political ideology and education) and country dummies..")

** Table 4: Post-Crisis
	set more off

* Analyse ESS Countries Fiscal Burden
* DE; SW; DK; UK
	use $loc/in/ESS/ESS_cleaned_merged.dta, clear
	keep  if (nation==5 | nation==6 | nation==14 | nation==21)
	recode nation (5=1 "DE") (21=4 " UK") (6=2 "DK") (14=3 "SE"),gen(nation1)

	eststo clear
	global controls "age i.female married c.education"
	eststo: oprobit proimig c.income##i.hskframe  i.nation1 $controls 
	bysort nation1: eststo: oprobit proimig c.income##i.hskframe $controls 


* Analyse Post-Crisis Data
* DE; SW; DK

	use $loc/in/post-crisis-data/Experiment_post-crisis.dta, clear 
	keep  if (Country==1 | Country==2 | Country==3 | Country==5 )
	
	replace income = income +1 
	recode Country (1=1 "DE") (2=4 " UK") (3=2 "DK") (5=3 "SE"),gen(nation)

	** Modelle
	global controls "age i.female i.active education" // controls
	eststo: oprobit proimig c.income##i.hskframe  i.nation $controls  
	bysort nation: eststo: oprobit proimig c.income##i.hskframe $controls  

* Joint Table 

esttab using "out/tables/Table4.rtf",replace se nogap compress b(3) ///
	varwidth(12) modelwidth(8) nonum ///
	keep(1.hskframe income 1.hskframe#c.income) ///
	star (* 0.05 ** 0.01)  	///
	varlabels(1.hskframe "HS-Frame" income "Income" 1.hskframe#c.income "HS-Frame X Income") ///
	order(1.hskframe income 1.hskframe#c.income) 	///
	mtitles("ESS Pooled" "ESS DE" "ESS DK" "ESS SW" "ESS UK" "Post-Crisis Pooled" "Post-Crisis DE" "Post-Crisis DK" "Post-Crisis SE" "Post-Crisis UK") ///
	indicate("Controls=1.female*" "Country FE= 1.nation") ///
	title({\b Table 4} {\i Support for highly Skilled and Low-Skilled Immigration - test of the Fiscal Burden Model using Dtaa Prior and Post Refguee Crisis}) ///
	addnotes("Ordered Probit Coefficients shown with standard errors in parentheses. All models include a set of covariates (age, gender, active in the labor force, education ) and country dummies. ")

** Figure 5: Descriptives
	use "in/ESS/ESS_cleaned_merged.dta", clear
	capture tab proimig,gen(proimig)
	
	* graph hbar proimig1 [pweight=dweight], ///
	*	over(income) over(fiscal) over(hskframe) ///
	*	ylabel(,nogrid) ytitle(Fraction) title("Opposition against migration")
capture lab def fe2 0 "FE1: Low" 1 "FE1: High"
capture lab val fe2 fe2

	graph dot proimig4 [pweight=weight] if active ==1, ///
		over(income) over(fe2) by(hskframe) ///
		marker(1, msymbol(O) mlwidth(thick)) ///
	        ylabel(,nogrid) ytitle(Percentage: Allow Many) xsize(8)
		
	graph export "out/figures/Figure5.pdf", as(pdf) replace

** Figure XX: Pred Prob

	global controls "age i.female married i.education lrscale"

	qui: oprobit proimig ib(3).income##i.hskframe $controls [pweight=weight]
	margins ib(3).income, over(hskframe fe2) at(female=1 education=2 married=1 age=49 lrscale=5) predict(outcome(4)) post 
	marginsplot, level(90)  ytitle("Predicted Probability: Allow Many") ///
		 legend(position(3) cols(1)) title("") xtitle("") xsize(8)
		
	graph export "out/figures/Figure6.pdf", as(pdf) replace

	eststo clear

** Figure 6	
	global controls "age i.female married c.education lrscale"
		
	capture gen diff_d5d1 = .
	capture gen se_3 = .
	capture gen nation_num3 = . 
	capture gen est_low3 = .
	capture gen est_high3 = .

	** Estimation Lists
	levelsof nation, local(level) 

	local estimates_list
	foreach g of local level {
		qui oprobit proimig i.income##i.hskframe $controls [pweight=weight] if nation == `g'
		qui margins ib(3).income, over(hskframe) predict(outcome(4)) post coefleg
		estimates store mar3_`g'
		local estimates_list `estimates_list' e3_`g'
		qui lincomest  ((_b[1.hskframe#5.income] -  _b[0bn.hskframe#5.income])-(_b[1.hskframe#1bn.income] -  _b[0bn.hskframe#1bn.income]))
		replace nation_num3 = `g' if nation == `g'
		matrix b3`g'=e(b)
		replace diff_d5d1 = b3`g'[1,1] if nation == `g'
		matrix V3`g' = e(V)
		replace se_3 = sqrt(V3`g'[1,1])
		replace est_low3 =   b3`g'[1,1] - 1.67*sqrt(V3`g'[1,1])  if nation == `g'
		replace est_high3 =  b3`g'[1,1] + 1.67*sqrt(V3`g'[1,1])  if nation == `g'
		}

	sort diff_d5d1
	capture egen tag1=tag(cntry)
	capture	egen rank3 = rank(diff_d5d1) if tag1
	
	labmask rank3, value(cntry)
	
	graph twoway (scatter rank3 diff_d5d1, legend(off) msymbol(O) xline(0 ///
		,lcolor(red)) yaxis(1) ///
		ylabel( 1/15,valuelabel angle(0))) ///
		(rspike est_high3 est_low3 rank3, ///
		hor ytitle("") xtitle("")) 
		
		graph export "out/figures/Figure6.pdf", as(pdf) replace
		
** FIGURE C1
	eststo clear

	global controls "age i.female married c.education lrscale"
		
	capture gen est_3 = .
	capture gen se_3 = .
	capture gen nation_num3 = . 
	capture gen est_low3 = .
	capture gen est_high3 = .

	** Estimation Lists
	levelsof nation, local(level) 

	local estimates_list
	foreach g of local level {
		qui oprobit proimig i.income##i.hskframe $controls [pweight=weight] if nation == `g'
		qui margins ib(3).income, over(hskframe) predict(outcome(4)) post coefleg
		estimates store mar3_`g'
		local estimates_list `estimates_list' e3_`g'
		qui lincomest  _b[1.hskframe#1bn.income] -  _b[0bn.hskframe#1bn.income]
		replace nation_num3 = `g' if nation == `g'
		matrix b3`g'=e(b)
		replace est_3 = b3`g'[1,1] if nation == `g'
		matrix V3`g' = e(V)
		replace se_3 = sqrt(V3`g'[1,1])
		replace est_low3 =   b3`g'[1,1] - 1.67*sqrt(V3`g'[1,1])  if nation == `g'
		replace est_high3 =  b3`g'[1,1] + 1.67*sqrt(V3`g'[1,1])  if nation == `g'
		}

		
	capture gen est_4 = .
	capture gen se_4 = .
	capture gen nation_num4 = . 
	capture gen est_low4 = .
	capture gen est_high4 = .

** Estimation Lists
	levelsof nation, local(level) 

	local estimates_list
	foreach g of local level {
		qui oprobit proimig i.income##i.hskframe $controls [pweight=weight] if nation == `g'
		qui margins ib(3).income, over(hskframe) predict(outcome(4)) post
		estimates store mar4_`g'
		local estimates_list `estimates_list' e4_`g'
		qui lincomest  _b[1.hskframe#5.income] -  _b[0bn.hskframe#5.income]
		replace nation_num4 = `g' if nation == `g'
		matrix b4`g'=e(b)
		replace est_4 = b4`g'[1,1] if nation == `g'
		matrix V4`g' = e(V)
		replace se_4 = sqrt(V4`g'[1,1])
		replace est_low4 =   b4`g'[1,1] - 1.67*sqrt(V4`g'[1,1])  if nation == `g'
		replace est_high4 =  b4`g'[1,1] + 1.67*sqrt(V4`g'[1,1])  if nation == `g'
		}
		
	gen diff_est=.
	replace diff_est = est_4 - est_3
	
	sort diff_est
	capture egen tag=tag(cntry)
	capture	egen rank2 = rank(diff_est) if tag
	gen y3 = rank2 - 0.35
	
	labmask rank2, value(cntry)
	
	graph twoway (scatter rank2 est_4, legend(off) msymbol(O) xline(0 ///
		,lcolor(red)) yaxis(1) ///
		ylabel( 1/15,valuelabel angle(0))) ///
		(rspike est_high4 est_low4 rank2, ///
		hor ytitle("") xtitle("XXX")) 		///
		|| (scatter y3 est_3, legend(off) msymbol(Oh) xline(0 ///
		,lcolor(red)) yaxis(1) ///
		ylabel( 1/15,valuelabel angle(0))) ///
		(rspike est_high3 est_low3 y3, ///
		hor ytitle("") xtitle("Treatment Effects for High and Low Income Respondents")) 
		
		graph export "out/figures/FigureC1.pdf", as(pdf) replace

