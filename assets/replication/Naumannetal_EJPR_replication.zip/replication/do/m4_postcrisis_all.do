************************
* Analyse Post-Crsisis 
*************************

* Analyse: Labour market competition


	** Modeles ***
	
	eststo clear
	global controls "age i.female i.active i.Country lrscale" // controls


	eststo: 
	oprobit proimig c.education##i.hskframe income $controls  
	eststo: oprobit proimig c.education##i.hskframe income $controls   if active==1
	eststo: oprobit proimig c.education##i.hskframe income $controls   if active==0


	** Figures ***

	capture tab proimig,gen(proimig)
	
	graph dot proimig5 [pweight=weight], ///
			over(education) over(hskframe) ///
			marker(1, msymbol(O) mlwidth(thick)) ///
			  ylabel(,nogrid) ytitle(Strongly agree) xsize(8)
	
	graph export "out/figures/Figure9.pdf", as(pdf) replace


	

* Analyse: Fiscal Burden


	** Modeles **

	eststo: oprobit proimig c.income##i.hskframe education $controls 
	eststo: oprobit proimig ib(2).income##i.hskframe education $controls  

	** Figures **

	capture tab proimig,gen(proimig)

	** Figure 3: Descriptives
	
	graph dot proimig5 [pweight=weight], ///
			over(income) over(hskframe) ///
			marker(1, msymbol(O) mlwidth(thick)) ///
			  ylabel(,nogrid) ytitle(Strongly agree) xsize(8)
			  
	graph export "out/figures/Figure10.pdf", as(pdf) replace
	
	
	
* Joint Table ***


esttab ,replace se nogap compress b(3) ///
	keep(education 1.hskframe 1.hskframe#c.education income  1.hskframe#c.income  0.income 1.income 3.income 4.income 0.income#1.hskframe 1.income#1.hskframe 3.income#1.hskframe 4.income#1.hskframe ) ///
	star (* 0.05 ** 0.01)  	///
	varlabels(education "Education" 1.hskframe "HS-Frame" 1.hskframe#c.education "HS-Frame X Education" ///
		1.hskframe "HS-Frame" income "Income" 1.hskframe#c.income "HS-Frame X Income" ///
		0.income "Q1" 1.income "Q2" 3.income "Q4" 4.income "Q5" ///
		0.income#1.hskframe "HS-Frame X Q1" 1.income#1.hskframe "HS-Frame X Q2" 3.income#1.hskframe "HS-Frame X Q4" 4.income#1.hskframe "HS-Frame X Q5"  ) ///
	order(1.hskframe education  income ) ///
	mtitles("Labout Comp. Model 1" "Labout Comp. Model 2" "Labout Comp. Model 3" "Fiscal Burden Model 1" "Fiscal Burden Model 2") ///
	indicate("Controls=1.female*" "Country FE= 1.Country") ///
	title({\b Table XX} {\i Support for highly Skilled and Low-Skilled Immigration - test of the Labor Market Competition Model}) ///
	addnotes("Ordered Probit Coefficients shown with standard errors in parentheses. All models include a set of covariates (age, gender, lrscale, active in the labor force) and country dummies. ")
