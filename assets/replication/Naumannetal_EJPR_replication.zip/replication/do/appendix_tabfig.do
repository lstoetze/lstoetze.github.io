************************
* Appendix: Tables and Figures
*************************

*** Descriptive table of all variables
tabstat proimig hskframe age female income inc1 inc2 inc3 inc4 inc5 education edu1 edu2 edu3 edu4 skill married active lrscale fe2 fe4 fe6 lmc1 lmc2 lmc3, statistics(n mean sd min max) col(statistics) format(%9.2f)

***[3] Are Control and Treatment group balanced?
foreach var of varlist age female income inc1 inc2 inc3 inc4 inc5 education edu1 edu2 edu3 edu4 married children urban active union lrscale {
logit hskframe `var' i.nation [pweight=pspwght]
}

*** Why not like this?
probit hskframe age female income education married children urban active union lrscale i.nation [pweight=dweight]


**** As expected there are no significant differences between treatment and control group for 15 of the 17 covariates we are using. Only those with upper secondary or vocational (edu3) and married or widowed (married) are underrepresented in the treatment group.
*** Wir kÃ¶nnen das so berichten, oder wir lassen den Familienstand als Covariable weg und nehmen education als kontibuierliche Variable. Dann hat auch Bildung keinen Einfluss.

*** Wenn man die Randomisierung in den einzelnen Landern anschaut, dann gibt es immer wieder einige Kontrollvariablen bei denen sich die beiden Gruppen unterscheiden.
*** Das ist aber ja normal und wird dann letztlich durch das Hinzufuegen der Variablen kontrolliert. Trotzdem sollten wir diese Unterschiede vielleicht aufzå©¬en.

gen w1=pspwght*pweight

probit hskframe education income i.euframe lrscale i.m children age i.female i.urban i.active i.union i.nation [pweight=dweight]

logit hskframe i.lrscale
