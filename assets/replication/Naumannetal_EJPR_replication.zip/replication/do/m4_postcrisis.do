************************
* Analyse Post-Crsisis 
*************************

	
	**** With a continuous income variable
	set more off

* Analyse ESS Countries Fiscal Burden
* DE; SW; DK; UK


	use $loc/in/ESS/ESS_cleaned_merged.dta, clear
	keep  if (nation==5 | nation==6 | nation==14 | nation==21)
	recode nation (5=1 "DE") (21=4 " UK") (6=2 "DK") (14=3 "SE"),gen(nation1)


	** Modelle

	eststo clear
	global controls "age i.female married c.education"
	eststo: oprobit proimig c.income##i.hskframe  i.nation1 $controls 
	bysort nation1: eststo: oprobit proimig c.income##i.hskframe $controls 


* Analyse Post-Crisis Data
* DE; SW; DK

	use $loc/in/post-crisis-data/Experiment_post-crisis.dta, clear 
	keep  if (Country==1 | Country==2 | Country==3 | Country==5 )
	
	replace income = income +1 
	recode Country (1=1 "DE") (2=4 " UK") (3=2 "DK") (5=3 "SE"),gen(nation)

	** Modelle
	global controls "age i.female i.active education" // controls
	eststo: oprobit proimig c.income##i.hskframe  i.nation $controls  
	bysort nation: eststo: oprobit proimig c.income##i.hskframe $controls  

	
* Joint Table ***

esttab using "out/tables/Table5.rtf",replace se nogap compress b(3) ///
	varwidth(12) modelwidth(8) nonum ///
	keep(1.hskframe income 1.hskframe#c.income) ///
	star (* 0.05 ** 0.01)  	///
	varlabels(1.hskframe "HS-Frame" income "Income" 1.hskframe#c.income "HS-Frame X Income") ///
	order(1.hskframe income 1.hskframe#c.income) 	///
	mtitles("ESS Pooled" "ESS DE" "ESS DK" "ESS SW" "ESS UK" "Post-Crisis Pooled" "Post-Crisis DE" "Post-Crisis DK" "Post-Crisis SE" "Post-Crisis UK") ///
	indicate("Controls=1.female*" "Country FE= 1.nation") ///
	title({\b Table 5} {\i Support for highly Skilled and Low-Skilled Immigration - test of the Fiscal Burden Model using Dtaa Prior and Post Refguee Crisis}) ///
	addnotes("Ordered Probit Coefficients shown with standard errors in parentheses. All models include a set of covariates (age, gender, active in the labor force, education ) and country dummies. ")
