****************************************
********* Analysis ******************
***************************************

 *use "$loc/in/ESS/ESS_cleaned_merged (v13).dta", clear

*** FIGURE 1 ***
	capture tab proimig,gen(proimig)

	graph hbar proimig1 proimig2 proimig3 proimig4 [pweight=dweight], ///
			over(hskframe) ///
			legend(label(1 "Allow none") label(2 "Allow a few") ///
			 label(3 "Allow some") label(4 "Allow many")) ///
			 ylabel(,nogrid) ytitle(Fraction)	 
	
	graph export "out/figures/Figure1.pdf", as(pdf) replace

**** FIGURE A1
	** Support for migration

	capture by nation, sort: egen meansupport=mean(proimig4)
	capture egen tagn=tag(cntry)
	sort meansupport
	capture	egen rank = rank(meansupport) if tagnation
	capture recode rank (7=3) (5=4) (3=5) (4=6) (6=7) (8=9) (9=8)
		
	graph hbar proimig4 [pweight=dweight], ///
				over(hskframe,label(labsize(small)) gap(-10)) over(nation, sort(rank) descending) ///
				 ylabel(,nogrid) ytitle("Fraction: Allow many") title("Support for migration",span) saving(support, replace)

	** Opposition against migration

	by nation, sort: egen meanopposition=mean(proimig1)
	sort meanopposition
	capture	egen rank1 = rank(meanopposition) if tagnation
	*** Das mit dem Ordnen hat irgendwie nicht ganz geklappt
	capture recode rank1 (3=4) (4=5) (5=3) (7=10) (8=7) (9=8) (10=9) (13=15) (14=13) (15=14)	

	graph hbar proimig1 [pweight=dweight], ///
				over(hskframe, label(labsize(small)) gap(-10)) over(nation, sort(rank1)) ///
				 ylabel(,nogrid) ytitle("Fraction: Allow none") title("Opposition against migration",span) saving(opposition, replace)
				 
	graph combine support.gph opposition.gph
	
*** TABLE A1
	tabstat proimig hskframe age female income inc1 inc2 inc3 inc4 inc5 education edu1 edu2 edu3 edu4 skill married active lrscale fe2 fe4 fe6 lmc1 lmc2 lmc3, statistics(n mean sd min max) col(statistics) format(%9.2f)

