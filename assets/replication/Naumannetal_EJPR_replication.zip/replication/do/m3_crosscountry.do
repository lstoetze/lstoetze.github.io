************************
* Cross-Country Analysis
*************************

set more off
use $loc/in/ESS/ESS_cleaned_merged.dta, clear

replace weight=dweight

** Set Controls
global controls "age i.female married c.income"

** Labour Market Competiton

	capture gen nation_num = . 
	capture gen int_est = . 
	capture gen int_est_low = .
	capture gen int_est_high = .


	levelsof nation, local(levels)
	* No Observations for 7 and 13 16 17 18 19

	foreach l of local levels  { 
		display "Regression for Country `l'"
		qui oprobit proimig c.education##i.hskframe $controls [pweight=weight]  if nation == `l'
		replace nation_num = `l' if nation == `l'	 
		replace int_est =  _b[1.hskframe#c.education] if nation == `l'
		replace int_est_low =  _b[1.hskframe#c.education] - 1.67*_se[1.hskframe#c.education]  if nation == `l'
		replace int_est_high =  _b[1.hskframe#c.education] + 1.67*_se[1.hskframe#c.education]  if nation == `l'
		
	}

		* Graph Interaction Effects
	sort int_est
	egen tag=tag(cntry)
	capture	egen rank = rank(int_est) if tag
		
	labmask rank, value(cntry)
	
	graph  twoway 	(scatter rank int_est, ///
				legend(off) xline(0 ,lcolor(red)) yaxis(1) ///
				ylabel( 1/15,valuelabel angle(0))) ///
			(rspike int_est_high int_est_low rank, ///
				hor ytitle("") xtitle("Interaction Effect HS-Frame X Education") ) 
	
	graph export "out/figures/Figure7.pdf", as(pdf) replace
	
***The same for skill level
	
	capture gen nation_num1 = . 
	capture gen int_est1 = . 
	capture gen int_est_low1 = .
	capture gen int_est_high1 = .
	
foreach l of local levels  { 
		display "Regression for Country `l'"
		qui oprobit proimig c.skill##i.hskframe $controls [pweight=weight]  if nation == `l'
		replace nation_num1 = `l' if nation == `l'	 
		replace int_est1 =  _b[1.hskframe#c.skill] if nation == `l'
		replace int_est_low1 =  _b[1.hskframe#c.skill] - 1.67*_se[1.hskframe#c.skill]  if nation == `l'
		replace int_est_high1 =  _b[1.hskframe#c.skill] + 1.67*_se[1.hskframe#c.skill]  if nation == `l'
		
	}	
	
	* Graph Interaction Effects
	sort int_est1
	capture	egen rank1 = rank(int_est1) if tag
		
	labmask rank1, value(cntry)
	
	graph  twoway 	(scatter rank1 int_est1, ///
				legend(off) xline(0 ,lcolor(red)) yaxis(1) ///
				ylabel( 1/15,valuelabel angle(0))) ///
			(rspike int_est_high1 int_est_low1 rank1, ///
				hor ytitle("") xtitle("Interaction Effect HS-Frame X Skill-Level") ) 
	
	graph export "out/figures/Figure7a.pdf", as(pdf) replace


** Fiscal Burden 

	
	capture gen nation_num2 = . 
	capture gen int_est2 = . 
	capture gen int_est2_low = .
	capture gen int_est2_high = .

global controls "age i.female married c.education"

	foreach l of numlist 1 2 3 4 5 6 8 9 10 11 12 14 15 20 21  { 
		display "Regression for Country `l'"
		qui oprobit proimig c.income##i.hskframe $controls [pweight=weight]  if nation == `l'
		replace nation_num2 = `l' if nation == `l'	 
		replace int_est2 =  _b[1.hskframe#c.income] if nation == `l'
		replace int_est2_low =  _b[1.hskframe#c.income] - 1.67*_se[1.hskframe#c.income]  if nation == `l'
		replace int_est2_high =  _b[1.hskframe#c.income] + 1.67*_se[1.hskframe#c.income]  if nation == `l'
		
	}
	
	
		* Graph Interaction Effects
	sort int_est2
	capture	egen rank2 = rank(int_est2) if tag
	
	* I do not know how to automatically assign labels here
	
	labmask rank2, value(cntry)
	
	graph  twoway 	(scatter rank2 int_est2, ///
				legend(off) xline(0 ,lcolor(red)) yaxis(1) ///
				ylabel( 1/15,valuelabel angle(0))) ///
			(rspike int_est2_high int_est2_low rank2, ///
				hor ytitle("") xtitle("Interaction Effect HS-Frame X Income") ) 
	
	graph export "out/figures/Figure8.pdf", as(pdf) replace

	******
	** Explanation of interaction effects? (income gradient)
	******
	
by nation, sort: egen meansupport=mean(proimig)

pwcorr int_est foreignborn socexp ncna ncfb uerate gdp meansupport if tag, star(.05)

pwcorr int_est2 foreignborn socexp ncna ncfb uerate gdp meansupport if tag, star(.05)
twoway scatter int_est2 ncfb if tag, mlabel(nation) || lfit int_est2 ncfb
twoway scatter int_est2 socexp if tag, mlabel(nation) || lfit int_est2 socexp
twoway scatter int_est2 meansupport if tag, mlabel(nation) || lfit int_est2 meansupport


**********
*** Do these results change if we use predicted probabilities instead of coefficients?
**********

gen d5q1q=.
lab var d5q1q "Difference in the predicted probabilities to allow many hsk-migrants"

foreach l of numlist 1 2 3 4 5 6 8 9 10 11 12 14 15 20 21  {
qui:oprobit proimig i.income##i.hskframe $controls [pweight=weight]  if nation == `l'
qui: margins ib(3).income, over(hskframe) predict(outcome(4)) post
mat b`l'=r(b)
replace d5q1q=(b`l'[1,10]-b`l'[1,6])-(b`l'[1,5]-b`l'[1,1]) if nation == `l'
}

pwcorr d5q1q foreignborn socexp ncna ncfb uerate gdp meansupport if tag, star(.05)
twoway scatter d5q1q ncfb if tag, mlabel(nation) || lfit d5q1q ncfb

sort d5q1q
capture	egen rank3 = rank(d5q1q) if tag
	
	
	labmask rank3, value(cntry)
	
	graph  twoway 	(scatter rank3 d5q1q, ///
				legend(off) xline(0 ,lcolor(red)) yaxis(1) ///
				ylabel( 1/15,valuelabel angle(0)))
			