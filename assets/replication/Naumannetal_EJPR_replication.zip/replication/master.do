*************************
* Replication files for:

*	Naumann, E., Stoetzer, L. & Pietrantuono, G (2018): Attitudes towards highly skilled and low-skilled immigration in Europe: A survey experiment in 15 European countries. European Journal of Political Research, 57, 4, 1009-1030, 
	*doi:   10.1111/1475-6765.12264
***********************

	clear all
	set more off
	
	** Set Paths
*!!!*	Please set the following global $loc to the path where this master.do-file is located and leave the rest of the folders as they are.
	global loc "PATH"
	cd $loc

	** Set Figure scheme
	capture net install gr0002_3, from(http://www.stata-journal.com/software/sj4-3)
	set scheme lean1
	
	
**************
* ESS
* The following data preparation files work if you download the European Social Survey data sets and the EU-Labour Force Surveys and copy them in the respective folders
* If you are mainly interested in the data analysis, we provide a dataset for analysis (ESS_cleaned_merged) which can be used to replicate our findings.
* So, the following data preparation steps are not necessary but might be of interest to check the data preparation and coding. That's we left them in the folders of the replication package, but commented them out.
**************

* PREPARE DATA FOR ESS

	** Prepare ESS
	*do in/prepare_ESS
	
	** Prepare Macro Dataset
	*do in/macro/makro.do
	
	** Prepare EU-LFS data on occupational labormarketcompetition indicator
	*do in/macro/lmc.do
	*do in/eulfs/eulfs.do
	*do in/macro/lmc2_lmc3.do
	
	
	** Merge with Macro Data and Occupation data
	*do in/merge_macro.do


	
	
* ANALYSE ESS

    use "in/ESS/ESS_cleaned_merged.dta", clear

	** Descriptives
	*** Figure 1, A1, Table A1
	
	do do/des_data

	** Models 1: Labour market competition
	*** Table 1,Figure 4 & 5
	  
	do do/m1_labourmarketcomp

	** Models 2: The Fiscal Burden of Public Services
	*** Table 2, Figure 5 & 6
	
	do do/m2_fiscalburden
		
	** Country Comparsion
	
	*do do/m3_crosscountry
	
	** Appendix Tables and Graphs
	
	*	do do/appendix/tabfig


* Post-Crisis
**************

* PREPARE DATA POST CRISIS
* Same as above: the full underlying data for each country is not (yet) publicly available, but we can provide a prepared dataset for replication purposes.
* Hence, the preparation do-files are for your information to check coding and data preparation. Please contact us, if you are interested in getting access to the original full dataset.
	
	** Prepare ESS YouGov
	*do in/prepare_postcrisis
	
	** Prepare & Merge Sweden Data
	*do in/prepare_postcrisis_sweden



* ANALYSE POST CRISIS

	** Models: Labour Market and Fiscal Burden Model
	do do/m4_postcrisis
	
	









