********************
* Coding ESS
*********************

* Document prepares ESS for analysis

***Load ESS 2014 v1
use "$loc/in/ESS/ESS7e02.dta", clear
qui: do "$loc/in/ESS/ESS_miss.do"

keep idno cntry ctzcntr ctzshipc brncntr cntbrthc livecnta maritalb chldhm domicil mbtru admaimg alpfpe alpfpne allbpe allbpne gndr agea edulvlb eisced eduyrs mnactic hincsrca hinctnta hincfel lrscale imbleco imtcjob imbgeco isco08 nacer2 inwdds inwmms inwyys pspwght pweight dweight

*** Controls ***
*** Sex ***
recode gndr (1=0 "Male") (2=1 "Female"),gen(female)
lab var female "Sex"

*** Age ***
clonevar age=agea
lab var age "Age"

*** Race in the Hainmueller Hiscox paper, we take place of birth
recode brncntr (1=0 "Native") (2=1 "Not born in country"),gen(migrant)
lab var migrant "Not born in country"

***
*Marital status
***
recode maritalb (1 2 5=1 "married/widowed") (3 4 6 =0 "divorced/single"),gen(married)
label var married "Married"


***
*Children at home
***
recode chldhm (1=1 "Yes") (2=0 "No children at home"),gen(children)
lab var children "Children at home"

***
*member of trade union or similar
***
recode mbtru (1=1 "Yes") (2 3 = 0 "No member"),gen(union)
lab var union "Union member"


***
* living in rural area
***
recode domicil (1 2 3 = 1 "urban area") (4 5 = 0 "rural area"),gen(urban)

***
*Main activity in last 7 days
***
recode mnact (1 3 = 1 "paid work or looking for a job") (2 4 5 6 7 8 9 = 0 "retired,disabled,in education,housework"),gen(active)
lab var active "Active on the laour market (in)"

***
*left right
***
* I leave it as a continous variable ranging from 0 to 10

***
encode cntry,gen(nation)

*** Main IVs
*** Education ***
*Hainmüller/Hiscox
* 1= No education/HS dropout, 2= High School, 3=Some college, 4= BA or higher
**ESS_ ES-ISCED
*0 	Not possible to harmonise into ES-ISCED 		 
*1 	ES-ISCED I , less than lower secondary 		 
*2 	ES-ISCED II, lower secondary 		 
*3 	ES-ISCED IIIb, lower tier upper secondary 		 
*4 	ES-ISCED IIIa, upper tier upper secondary 		 
*5 	ES-ISCED IV, advanced vocational, sub-degree 		 
*6 	ES-ISCED V1, lower tertiary education, BA level 		 
*7 	ES-ISCED V2, higher tertiary education, >= MA level 	
recode eisced (1=1 "< lower secondary") (2 3 =2 "lower secondary") (4 5 =3 "upper secondary") (6 7 = 4 "tertiary education") (55=.),gen(education)	 
lab var education "Education"
tab education,gen(edu)


*****************
*** Skill Measure based on ISCO
*****************

*** Create one-digit ISCO: isco08_1
gen isco08_1 = int(isco08/1000)
lab define isco08_1 ///
	1 "Managers" ///
	2 "Professionals" ///
	3 "Technicians and associate professionals" ///
	4 "Clerical support workers" ///
	5 "Service and sales workers" ///
	6 "Skilled agricultural, forestry and fishery workers" ///
	7 "Craft and related trades workers" ///
	8 "Plant and machine operators and assemblers" ///
	9 "Elementary occupations" ///
	0 "Armed forces occupations"
lab val isco08_1 isco08_1

*** Generate 3-digit ISCO code: isco08_3
gen isco08_3 = int(isco08/10)
replace isco08_3=0 if isco08_3==11 | isco08_3==21 | isco08_3==31
*** Generate 2-digit ISCO code: isco08_2
gen isco08_2 = int(isco08/100)
replace isco08_2=0 if isco08_2==1 | isco08_2==2 | isco08_2==3

**** See coding scheme in dropbox
recode isco08_1 (1=4) (2=4) (3=3) (4/8=2) (9=1) (0=1),gen(skill)
replace skill=3 if skill==4 & isco08_2==14
replace skill=4 if skill==1 & isco08==110

lab var skill "Skill Level"


*** Income ***
*** Is available in deciles
*** Hainmueller/Hiscox use quartiles, we recode it into quintiles instead
*** Data for Estonia is missing completely. Can/Need to be added from country file!
recode hinctnta (1 2= 1 "Q1") (3 4 =2 "Q2") (5 6=3 "Q3") (7 8 =4 "Q4") (9 10 =5 "Q5"),gen(income)
lab var income "HH income (quintiles)"
tab income,gen(inc)

****
* Wir haben im ESS noch viel mehr andere Variablen, die bei Hainmueller/Hiscox nicht verfügbar waren: bsp. ISCO-Kodierung
* Damit ließe sich auch die Anzahl der Migranten im Beruf des jeweiligen Befragten zuspielen.
****

*** DV ***
gen proimig=.
foreach var of varlist alpfpe alpfpne allbpe allbpne {
replace proimig = `var' if proimig==.a | proimig==. | proimig>4
}
*** Rekodierung so dass hohe Werte Zustimmung zu Einwanderung bedeutet
*** Unterschied zu Hainmueller/Hiscox: 5erSkala (agree/disagree, hier haben wir eine 4er-Skala mit fragenspezifischen Labeln)
replace proimig=5-proimig
lab def proimig 1 "Allow none" 2 "Allow a few" 3 "Allow some" 4 "Allow many to come and live here"
lab val proimig proimig
mvdecode proimig,mv(-4 -3 -2 -1)
*** Durch die 4er Skala wird die Dichotomisierung in support (agree)/oppose (disagree) immigration nicht ganz so eindeutig.
recode proimig (1 2 = 0 "Oppose") (3 4 = 1 "Support"),gen(supportimig)

*** Treatment Variable
gen hskframe=.
replace hskframe=1 if admaimg==1 | admaimg==2
replace hskframe=0 if admaimg==3 | admaimg==4
lab var hskframe "High-skilled migrants"

lab def hskframe 0 "Low-skilled migrants" 1"Highly skilled migrants"
lab val hskfram hskframe



gen euframe=.
replace euframe=1 if admaimg==1 | admaimg==3
replace euframe=0 if admaimg==2 | admaimg==4
lab def euframe 1 "from European country" 0 "from non-European country"
lab val euframe euframe
lab var euframe "Migrants from EU country"


*********************
** Create sample for analysis
*********************
 
 * We drop Estonia (because income is missing)
 drop if nation==7
 
 *** We drop cases that were surveyed April 2015 or later
 gen crisis=0
 replace crisis=1 if inwmms>3 & inwyys==2015
 
 *** We drop Hungary, Israel, Lithuania, Poland, and Portugal
 drop if nation==12 | nation==14 | nation==15 | nation==18 | nation==19
 
 *** We delete 338 cases in Austria, 96 in Spain and 384 in the UK
 drop if crisis==1
 
 * We restrict analysis to natives
  drop if migrant==1
  
  drop crisis
 ********
 *Gewicht um die unterschiedlichen Sample Sizes (im Vergleich zur Bevölkerungsgrösse) zu beachten
 ********
 gen weight=pweight*dweight
 
 recode nation (1=1 "Austria") (2=2 "Belgium") (3=3 "Switzerland") (4=4 "Czech Republic") (5=5 "Germany") (6=6 "Denmark") ///
				(8=20 "Spain") (9=8 "Finland") (10=9 "France") (11=21 "UK") (13=10 "Ireland") (16=11 "Netherlands") (17=12 "Norway") ///
				(20=14 "Sweden") (21=15 "Slovenia"),gen(nation1)
drop nation
rename nation1 nation
lab var nation "Country"

 * Save Dataset
 save "$loc/in/ESS/ESS_cleaned.dta", replace

