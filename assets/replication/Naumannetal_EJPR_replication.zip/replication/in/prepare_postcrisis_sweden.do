*************************
* Prepare Dataset for post-crisis analysis
*************************

*** Sweden Citizen Panel 
use $loc/in/post-crisis-data/Sweden/mp18_s4_naumann_20160112/mp18_s4_naumann_20160112.dta , clear


*** Controls ***


	** Sex
	recode q7 (2 3=0 "Male") (1=1 "Female"),gen(female)
	lab var female "Sex"
	
	** Age 
	clonevar age=age2015 
	lab var age "Age"

	** Race in the Hainmueller Hiscox paper, we take place of birth
	recode q10 (1=0 "Native") (2 3=1 "Not born in country"),gen(migrant)
	lab var migrant "Not born in country"

	** Main activity in last 7 days
	recode q447 (1 2 3 4 5 = 1 "paid work or looking for a job") ( 6 7 8 9 = 0 "retired,disabled,in education,housework"),gen(active)
	lab var active "Active on the laour market (in)"
	tab active

	** left right
	recode q421  (777 = .) , gen(lrscale)
	lab var lrscale "Left-Right Self Placement"

*** Main IVs ***
	tab q449
	
	** Education
		* Das ist ein wirrwar. Trotzdem erstmal die 4-er Einteilung.
		
		recode q449 (1 2=1 "< lower secondary") (3 4 =2 "lower secondary") (5 6 7 =3 "upper secondary") (8 9 = 4 "tertiary education"),gen(education)	 
		lab var education "Education"
		

	** Income
		recode q452 (18 19 =. )
		capture egen income  = cut(q452), group(5)	

		tab income
		lab var income "HH income (quintiles)"



	** DV 
	
	gen proimig=.
	foreach var of varlist s4_q291 s4_q292  {
		replace proimig = `var' if proimig==.a | proimig==.
	}

	
	replace proimig= -1*(proimig - 6)
	lab def proimig 1 "strongly disagree" 2 "somewhat disagree" 3 "neither agree nor disagree" 4 "somewhat agree" 5 "strongly agree"
	lab val proimig proimig


	** Treatment Variable
	
	gen hskframe=.
	replace hskframe=1 if s4_q291!=. 
	replace hskframe=0 if s4_q292!=.
	lab var hskframe "High-skilled migrants"

	lab def hskframe 0 "Low-skilled migrants" 1"Highly skilled migrants"
	lab val hskframe hskframe
	
	tab hskframe


** Create sample for analysis


	* We restrict analysis to natives
	drop if migrant==1
	drop if hskframe==.
	
	 
	* Keep
	gen Country = 5 
	gen weight = .
	keep hskframe proimig income education lrscale active age female Country weight
	
	
	* Save 
	save $loc/in/post-crisis-data/Sweden/Experiment_Sweden.dta, replace 
	
	
	* Append 
	append using $loc/in/post-crisis-data/YouGov/YouGov.dta
	
	label define cn_name 1 "DE" 2 "UK" 3 "DK" 4 "IT" 5 "SW"
	label values Country cn_name
		
	save $loc/in/post-crisis-data/Experiment_post-crisis.dta, replace 

