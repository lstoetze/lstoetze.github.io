**** Prepare measures for labor market competition (see Polavieja, 2016 or Ortega & Polavieja 2012) from ESS5

use "$loc/in/ESS/ESS5e03.2_F1.dta", clear

*** Reduce to native employed respondents between 20 and 64
keep if brncntr==1
keep if agea>19 & agea<65
keep if mnactic==1

*** Generate 3-digit ISCO code: isco08_3
gen isco08_3 = int(iscoco/10)
replace isco08_3=0 if isco08_3==10

*** Generate 2-digit ISCO code: isco08_2
gen isco08_2 = int(iscoco/100)
replace isco08_2=0 if isco08_2==1

*** Calculate means of Skill specificity measure: lmc2
*If somebody with the right education and qualifications replaced you in your job, how long would it take for them to learn to do the job reasonably well?
* Answers were recoded into months - wie auch immer man das sinnvoll macht?
*1	1 day or less	 
*2	2-6 days	
*3	1-4 weeks	
*4	1-3 months	 
*5	More than 3 months, up to 1 year	
*6	More than 1 year, up to 2 years	
*7	More than 2 years, up to 5 years	
*8	More than 5 years	
 
recode jblrn (1=0.03) (2=0.13) (3=0.58) (4=2) (5=8) (6=18) (7=48) (8=60),gen(ss) 

gen lmc2=.
levelsof isco08_3, local(levels) 
  foreach l of local levels {
 	qui: sum ss if isco08_3 == `l', meanonly
	replace lmc2=r(mean) if isco08_3 == `l'
 }
 lab var lmc2 "Labor Market Competition 2:Skill Specificity"
 
 
gen lmc2_1=.
levelsof isco08_2, local(levels) 
  foreach l of local levels {
 	qui: sum ss if isco08_2 == `l', meanonly
	replace lmc2_1=r(mean) if isco08_2 == `l'
 }
 
*** Calculate means of monitoring costs: lmc3
* How difficult or easy do you think it is for your immediate boss to know how much effort you put into your work?
* 0	Extremely difficult - 10 extremely easy

gen mc=10-bseftwk
gen lmc3=.

levelsof isco08_3, local(levels) 
  foreach l of local levels {
 	qui: sum mc if isco08_3 == `l', meanonly
	replace lmc3=r(mean) if isco08_3 == `l'
 }
lab var lmc3 "Labor Market Competition 3:Monitoring Costs"

gen lmc3_1=.

levelsof isco08_2, local(levels) 
  foreach l of local levels {
 	qui: sum mc if isco08_2 == `l', meanonly
	replace lmc3_1=r(mean) if isco08_2 == `l'
 }
 
egen tag=tag(isco08_2)
keep if tag==1
 
keep isco08_2 lmc2 lmc2_1 lmc3 lmc3_1


save "$loc/in/macro/lmc2_lmc3.dta", replace
