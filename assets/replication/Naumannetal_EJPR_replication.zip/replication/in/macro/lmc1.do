import excel "$loc\in\macro\foreignborn_isco08.xls", sheet("Sheet1") cellrange(A1:E232) firstrow clear
gen lmc1=.
replace lmc1=1 if fb_occ>fb_mean
replace lmc1=0 if fb_occ<fb_mean
lab var lmc1 "Labour Market Competition 1 (based on EU-LFS)"
save "$loc\in\macro\lmc1.dta"
