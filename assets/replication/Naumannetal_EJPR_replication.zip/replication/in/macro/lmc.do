***Load ESS 2014 v1
use "$loc/in/ESS/ESS7e02.dta", clear
qui: do "$loc/in/ESS/ESS_miss.do"

keep idno cntry ctzcntr ctzshipc brncntr cntbrthc livecnta maritalb chldhm domicil mbtru admaimg alpfpe alpfpne allbpe allbpne gndr agea edulvlb eisced eduyrs mnactic hincsrca hinctnta hincfel lrscale imbleco imtcjob imbgeco isco08 nacer2 pweight dweight

*** Race in the Hainmueller Hiscox paper, we take place of birth
recode brncntr (1=0 "Native") (2=1 "Not born in country"),gen(migrant)
lab var migrant "Not born in country"

***
*Main activity in last 7 days
***
recode mnact (1 3 = 1 "paid work or looking for a job") (2 4 5 6 7 8 9 = 0 "retired,disabled,in education,housework"),gen(active)
lab var active "Active on the laour market (in)"

***
encode cntry,gen(nation)

gen isco08_3 = int(isco08/10)
replace isco08_3=0 if isco08_3==11 | isco08_3==21 | isco08_3==31

keep if active==1

by nation isco08_3,sort: egen lmc=mean(migrant)
by nation,sort: egen fb=mean(migrant)

gen lmc_bin=.
replace lmc_bin=1 if lmc>fb
replace lmc_bin=0 if lmc<fb

recode nation (1=1 "Austria") (2=2 "Belgium") (3=3 "Switzerland") (4=4 "Czech Republic") (5=5 "Germany") (6=6 "Denmark") ///
				(8=20 "Spain") (9=8 "Finland") (10=9 "France") (11=21 "UK") (13=10 "Ireland") (16=11 "Netherlands") (17=12 "Norway") ///
				(20=14 "Sweden") (21=15 "Slovenia"),gen(nation1)
drop nation
rename nation1 nation

keep nation idno lmc lmc_bin
lab var lmc "Labor Market Competition: Share of fb in occupation (based on ESS)"
lab var lmc_bin "Labor Market Competition: Share of fb in occupation above country mean (based on ESS)"

 * Save Dataset
 save "$loc/in/macro/lmc.dta", replace

