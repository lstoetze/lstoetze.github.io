
import excel "$loc/in/macro/makro_extended.xlsx", sheet("Sheet1") cellrange(A4:T25) firstrow clear
drop C G

lab var cntry "Country"
lab var foreignborn	"Share of foreign-born population"
lab var socexp	"Social Expenditures per capita as share of GDP in US$"
lab var ncna	"Net contribution of natives"
lab var ncfb	"Net contribution of foreign borns"
lab var elfb	"employment rate of low-educated foreign borns"
lab var elna	"employment rate of low-educated natives"
lab var ehfb	"employment rates of highly educated foreign borns"
lab var ehna	"employment rates of highly educated natives"
lab var lena	"Share of low educated among natives"
lab var lefb	"Share of low educated among foreign borns"
lab var hena	"Share of high educated among natives"
lab var hefb	"Share of high educated among foreign borns"
lab var drfb	"Dependency ratio (share of 65+ compared to the working population) of foreign born"
lab var drna	"Dependency ratio (share of 65+ compared to the working population) of natives"
lab var uerate	"Unemployment rate (yearly average) 2014"
lab var gdp	"GDP per capita in current PPP in US$"

*** We drop Hungary, Israel, Lithuania, Poland, and Portugal
 drop if nation==13 | nation==16 | nation==17 | nation==18 | nation==19
 
***** FISCAL EXPOSURE MEASURE 1: Hainmueller/Hiscox etc.
gen highexp = 0
egen temp = median(socexp)
replace highexp = 1 if socexp > temp
drop temp

gen highimmig=0
sum foreignborn
display r(mean)
replace highimmig = 1 if foreignborn > r(mean)

gen fe1=highexp*highimmig
lab var fe1 "Fiscal Exposure 1 (Hainmueller/Hiscox)"

***** FISCAL EXPOSURE MEASURE 2: our direct measure of the net contribution of migrants
gen fe2=.
replace fe2=1 if ncfb<0
replace fe2=0 if ncfb>0

lab var fe2 "Fiscal Exposure 2: Net contribution of foreign born"

***** FISCAL EXPOSURE MEASURE 3: do migrants contribute more than natives?
gen ncrel=ncfb-ncna

egen temp = median(ncrel)
gen fe3 = 0
replace fe3 = 1 if ncrel > temp
drop temp ncrel

lab var fe3 "Fiscal Exposure 3: Foreign born contribute more than natives"

***** Fachini and Mayda's (2009) measure of skill mix

***Calculate the ratio of skilled (ISCED 03 and higher) to unskilled (ISCED 00,01,02) labour for natives and foreignborn
gen rna=(100-lena)/lena
gen rfb=(100-lefb)/lefb
*** "relative skill ratio equals the log of (one plus) the relative skill composition of natives to immigrants. The higher the relatve skill ratio the more unskilled immigrants are compared to natives." p.303
gen rsc=log(1+(rna/rfb))

lab var rsc "Relative Skill Ratio (Facchini/Mayda)"
drop rna rfb


save "$loc\in\macro\makro.dta", replace
