*************************
* Prepare Dataset for post-crisis analysis
*************************

** YouGov Dataset
use $loc/in/post-crisis-data/YouGov/YouGov_Datensatz_Uni_Mannehim_Arbeitsmarktmarkt_v1.dta , clear


*** Controls ***


	** Sex
	recode q01_a9 (1=0 "Male") (2=1 "Female"),gen(female)
	lab var female "Sex"

	** Age 
	clonevar age=q_alter
	lab var age "Age"

	** Race in the Hainmueller Hiscox paper, we take place of birth
	recode q18 (2=0 "Native") (1 777=1 "Not born in country"),gen(migrant)
	lab var migrant "Not born in country"

	** Main activity in last 7 days
	recode q03 (1 7 = 1 "paid work or looking for a job") (3 = 0 "retired,disabled,in education,housework"),gen(active)
	lab var active "Active on the laour market (in)"

	** left right
	recode q10 (777 = .) , gen(lrscale)
	lab var lrscale "Left-Right Self Placement"


*** Main IVs ***

	** Education
		* Das ist ein wirrwar - aber trotzdem!
		
gen edu=.

**************
**** Germany
****************

** Less then lower secondary
replace edu = 1 if q13_DE==5
replace edu = 1 if q13_DE==1 & (q14_DE!= 4 | q14_DE !=5)
replace edu = 1 if q14_DE==1

*** lower secondary
replace edu = 2 if q13_DE==2 & q14_DE== 1 
replace edu = 2 if q13_DE==3 & q14_DE== 1
replace edu = 2 if q13_DE==4 & q14_DE <4
replace edu = 2 if q13_DE==2 & q14_DE == 777
replace edu = 2 if q13_DE==3 & q14_DE == 777
replace edu = 2 if q13_DE==4 & q14_DE == 777
replace edu = 2 if q13_DE==2 & q14_DE == 2
replace edu = 2 if q13_DE==3 & q14_DE == 2

*** upper tier secondary, advanced vocational
replace edu = 3 if q14_DE==4


*** tertiary education
replace edu = 4 if q14_DE==5

*************
**** UK
*************

***less than lower secondary
replace edu=1 if q13_EN==7 & q14_EN==11
replace edu=1 if q13_EN==6 & q14_EN==11

*** lower secondary
replace edu=2 if q13_EN==5 & q14_EN==11
replace edu=2 if q13_EN==4 & q14_EN==11
replace edu=2 if q13_EN==3 & q14_EN==11
replace edu=2 if q13_EN==2 & q14_EN==11
replace edu=2 if q14_EN==10

*** upper secondary, advanced vocational
replace edu=3 if q13_EN==1 & q14_EN==11
replace edu=3 if q14_EN==6
replace edu=3 if q14_EN==7
replace edu=3 if q14_EN==8
replace edu=3 if q14_EN==9

***tertiary
replace edu=4 if q14_EN==1
replace edu=4 if q14_EN==2
replace edu=4 if q14_EN==3
replace edu=4 if q14_EN==4
replace edu=4 if q14_EN==5

***********
*Denmark
**********
replace edu=1 if q13_DK==1
replace edu=1 if q13_DK==2

replace edu=2 if q13_DK==3
replace edu=2 if q13_DK==4

replace edu=3 if q13_DK==5
replace edu=3 if q13_DK==6
replace edu=3 if q13_DK==7

replace edu=4 if q13_DK==8
replace edu=4 if q13_DK==9
replace edu=4 if q13_DK==10
replace edu=4 if q13_DK==11

*************
* Italy
*************
replace edu=1 if q13_IT==0
replace edu=1 if q13_IT==1
replace edu=1 if q13_IT==2

replace edu=2 if q13_IT==3

replace edu=3 if q13_IT==4
replace edu=3 if q13_IT==5

replace edu=4 if q13_IT==6
replace edu=4 if q13_IT==7
replace edu=4 if q13_IT==8

rename edu education
lab define education 1 "< lower secondary" 2 "lower secondary" 3 "upper secondary" 4 "tertiary education"	 
lab val education education

	** Income
	
		capture drop income
		capture gen income = . 
				
		* Germany & Itlay 
		replace q11_DE_IT =. if q11_DE_IT== 13
		capture egen income_quantile_DE_IT  = cut(q11_DE_IT ), group(5)
		replace income = income_quantile_DE_IT if Country == 1 | Country == 4

		* England
		replace q11_EN =. if q11_EN == 666
		capture egen income_quantile_EN = cut(q11_EN ), group(5)
		replace income = income_quantile_EN if Country == 2 

		* Denmark
		replace q11_DK =. if q11_DK == 13
		capture egen income_quantile_DK = cut(q11_DK ), group(5)
		replace income = income_quantile_DK if Country ==3
		

		tab income
		lab var income "HH income (quintiles)"



	** DV 
	
	gen proimig=.
	foreach var of varlist q09_A q09_B {
		replace proimig = `var' if proimig==.a | proimig==.
	}
	
	replace proimig = . if proimig==777
	
	replace proimig= -1*(proimig - 6)
	lab def proimig 1 "strongly disagree" 2 "somewhat disagree" 3 "neither agree nor disagree" 4 "somewhat agree" 5 "strongly agree"
	lab val proimig proimig


	** Treatment Variable
	
	gen hskframe=.
	replace hskframe=1 if Experiment3==1 
	replace hskframe=0 if Experiment3==2 
	lab var hskframe "High-skilled migrants"

	lab def hskframe 0 "Low-skilled migrants" 1"Highly skilled migrants"
	lab val hskfram hskframe


** Create sample for analysis


	 * We restrict analysis to natives
	 drop if migrant==1
	 
	 * Keep
	keep hskframe proimig income education lrscale active age female Country weight
	
	* Save 
	save $loc/in/post-crisis-data/YouGov/YouGov.dta, replace 
	
