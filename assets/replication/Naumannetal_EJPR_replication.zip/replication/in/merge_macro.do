****************
* Merge Macro to ESS
****************

use "$loc/in/ESS/ESS_cleaned.dta", clear

	merge m:1 nation using in/macro/makro.dta, keepusing(socexp foreignborn ncfb ncna highexp highimmig fe1 fe2 fe3 rsc gdp uerate drfb drna)
	drop _merge
	 lab var highexp "Social expenditures above the mean"
	 lab var highimmig "% of foreign born above the median"

* Merge Occupational Labor Market Competition indicators to ESS


******************
*** Share of migrants in each occupation (from ESS)
******************
merge 1:m nation idno using in/macro/lmc.dta, keepusing(lmc lmc_bin)
drop if _merge==2
drop _merge


*********************
*** From EU-LFS: lmc1
*********************
clonevar isco3d=isco08_3

* For Poland (nation==13) and Slovenia (nation==13) we take the 2 digit isco to match to EU LFS
replace isco3d=isco08_2*10 if nation==15 | nation==13

merge m:m nation isco3d using in/eulfs/eulfs.dta, keepusing(lmc1 fb_mean)
**** We loose 2,434 observations that provide only 2digit isco coding in the ESS dataset. We could calculate these numbers from the EU-LFS.
drop if _merge==2
drop _merge

***** INDICATOR MEASURING LABOR MARKET COMPETITION********************************
*** LaborMarketCompetition = Share of foreign born in R's occupation - average share of foreign born in R's country
*** The higher lmc1_1 the higher is the labor market competition with migrants.
**********************************************************************************
replace lmc1=lmc1-fb_mean


**************
*** Based on skill specificity and monitoring costs in the respective occupation (Polavieja/Ortega): lmc2 lmc3
**************

*merge m:1 isco08_3 using in/macro/lmc2_lmc3.dta, keepusing(lmc2 lmc3)
merge m:1 isco08_2 using in/macro/lmc2_lmc3.dta, keepusing(lmc2_1 lmc3_1)
rename lmc2_1 lmc2
rename lmc3_1 lmc3
lab var lmc2 "Labor Market Competition 2:Skill Specificity (Polavieja)"
lab var lmc3 "Labor Market Competition 3:Monitoring Costs (Polavieja)"
drop _merge

lab var isco08_1 "Occupation: 1-digit ISCO 08"
lab var isco08_2 "Occupation: 2-digit ISCO 08"
lab var isco08_3 "Occupation: 3-digit ISCO 08"

drop if nation==7
drop if nation==13
drop if nation==16
drop if nation==17
drop if nation==18
drop if nation==19


***********
*** More measures of fiscal exposure
***********
**4 Multiplying the net contribution of mirgants and the share of foreignborn	
gen fe4=foreignborn*ncfb
recode fe4 (-100000/20125=1) (20125.1/1000000=0)

**5 Countries that have a low (or negative) net contribution of foreign born and high share of them
gen fe5=0
replace fe5=1 if ncfb<2400 & foreignborn > 12.5	

*** Subjective measure of fiscal burden: Do migrants take out more than they contribute or do they contribute more than they take out? (imbleco)
gen fe6=.
replace imbleco=10-imbleco
levelsof nation, local(levels)
foreach l of local levels { 
 	summarize imbleco [w=weight] if nation == `l' 
        replace fe6 = r(mean) if nation == `l' 
  } 
  
 **High values mean high fiscal exposure (Split at the median with the middle case as a low fiscal exposure country)
 recode fe6 (0/5.695=0) (5.7/10=1)
 
 lab var fe2 "Fiscal Exposure 1: Net Contribution of Foreign Born"
 lab var fe4 "Fiscal Exposure 2: Net Contribution of Foreign Born X Foreign Born"
 lab var fe6 "Fiscal Exposure 3: Subjective Fiscal Net Contribution"
 lab var fe1 ""
 lab var fe3 ""
 
 *** LMC4
 tab imtcjob
 gen lmc4 = .
 replace lmc4 = 1 if imtcjob < 5
 replace lmc4 = 0 if imtcjob >= 5 & imtcjob < 11
 
 lab var lmc4 "Take Jobs Away"

save "$loc/in/ESS/ESS_cleaned_merged.dta", replace
